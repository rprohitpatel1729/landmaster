export const environment = {
    apiUrl: 'https://localhost:7068',
    production: false
  };