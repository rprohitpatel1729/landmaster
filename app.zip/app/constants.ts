export const ROLE_KEY = 'role';

export const TOKEN_KEY = 'token';

export const USERID_KEY = 'userid';